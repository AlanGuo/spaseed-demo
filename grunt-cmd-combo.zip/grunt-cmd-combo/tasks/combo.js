/*
 * combo.js
 *
 * Copyright (c) 2012 'PerfectWorks' Ethan Zhang
 * Licensed under the MIT license.
 * https://github.com/gruntjs/grunt/blob/master/LICENSE-MIT
 */

/*jslint node: true*/

module.exports = function (grunt) {
    var path = require('path');
    var fs = require('fs');
    var _ = require('underscore');
    var allModules = [];

    var cmdModule = require('../lib/cmdModule')(grunt);

    grunt.registerMultiTask('combo', 'Concat SeaJS modules', function () {
        var options = this.options();

        var loader = path.resolve(__dirname, '..', 'lib', 'loader.js');

        //依赖数组提至外面
        var depsQueue = [];
        var modules = {};

        this.files.forEach(function (file) {
            var jsFile = file.src[0];
            var root = file.orig.cwd;

            var modName = jsFile.replace(root, '').replace(/\.js$/, '');

            cmdModule.moduleWalk(modName, null, root, function (modName, ast) {
                if (!modules[modName]) {
                    var result = cmdModule.generateJSCode(ast, modName, options);
                    modules[modName] = result.code;
                }
            }, depsQueue, options);

            depsQueue.push(modName);
        });

        depsQueue = depsQueue.sort();

        // console.log(depsQueue);

        //合成一个文件
        var finalCode = depsQueue.reduce(function (memo, modName) {
            memo = memo.replace(/\r\n/g, '\n').replace(/\r/g, '\n') + ';\n';

            var lineCount = memo.split('\n').length - 1;

            return memo + modules[modName];
        }, '');

        var destFile = path.normalize(options.dest);

        grunt.log.writeln('Module ' + destFile + ' created.');

        grunt.file.write(destFile, finalCode);

    });
};

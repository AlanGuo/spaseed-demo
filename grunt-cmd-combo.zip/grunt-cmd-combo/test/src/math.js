/*jslint browser: true*/
/*global define*/

define(function () {
    return {
        plus: function (a, b) {
            return a + b;
        }
    };
});
